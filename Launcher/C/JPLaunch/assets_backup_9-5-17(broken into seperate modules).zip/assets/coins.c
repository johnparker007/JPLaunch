#include "headers.h"

void CoinsInitialise()
{
	// TODO - making proper coin system when not drinking, this is just to test some character drawing
	for(unsigned char coinIndex = 0; coinIndex < kCoinCount; coinIndex++)
	{
		_coinCurrentX[coinIndex] = 2 + (coinIndex * 2);
		_coinCurrentY[coinIndex] = 22 + (coinIndex * 12);
		_coinPreviousX[coinIndex] = _coinCurrentX[coinIndex];
		_coinFrame[coinIndex] = coinIndex % kCoinFrameCount; // slow but doesn't matter during init
		_coinActive[coinIndex] = TRUE;
	}

	_coinAttributeValues[0] = ATTRIBUTE_ENCODE(6, 0, 1, 0);
	_coinAttributeValues[1] = ATTRIBUTE_ENCODE(7, 0, 1, 0);
	_coinAttributeValues[2] = ATTRIBUTE_ENCODE(6, 0, 1, 0);
	_coinAttributeValues[3] = ATTRIBUTE_ENCODE(6, 0, 0, 0);
}

void CoinsUpdate()
{
// TODO this does work, however maybe make these two nearly identical functions with a macro or something?  Or more functions and trust sdcc?
// TODO perform more testing to get this sorted with cleaner code (as same will be true for Sprite collisions)
// Maybe even a function pointer that is set here, then the collision check performed in the function?  Or a goto?
	if(_playerY < kPlayerMediumY)
	{
		CoinsUpdatePlayerLowYOptimisedCollisionCheckVersion();
	}
	else
	{
		CoinsUpdatePlayerHighYOptimisedCollisionCheckVersion();
	}
}

void CoinsUpdatePlayerHighYOptimisedCollisionCheckVersion()
{
	// TODO - making proper coin system when not drinking, this is just to test some character drawing
	//unsigned char coinIndex;
	//unsigned char coinCurrentX, coinCurrentY; // assigning into these seemed to make things slower?
	
	// TODO IMPORTANT check - a Coin struct may compile far more efficient than indexing into all these seperate arrays!!!!
	// TODO If the above is true, do the same for the Spriute data etc??  Rather than indexiing into seperate arrays in loops!
	for(unsigned char coinIndex = 0; coinIndex < kCoinCount; coinIndex++)
	{
		// move if active, check offscreen (TODO collision detection will also go here)
		if(_coinActive[coinIndex])
		{
			_coinCurrentX[coinIndex] -= kScrollSpeedCurrent;

			if
			(
				_coinCurrentX[coinIndex] > kCharacterColumnWidth 
				|| 
				// ***THE ORDER OF THE Y CHECKS IS THE ONLY DIFFERENCE BETWEEN THE LOW AND HIGH OPTIMISED FUNCTIONS!!!
				(	_coinCurrentX[coinIndex] < kPlayerStartX + 3 // TODO make kPlayerCoinCollisionWidth define
					&& _coinCurrentX[coinIndex] >= kPlayerStartX
					&& _coinCurrentY[coinIndex] >= _playerY 
					&& _coinCurrentY[coinIndex] < _playerY + kScreenTileHeight
				)  
			)
			{

if(_coinCurrentX[coinIndex] > kCharacterColumnWidth)
{
	_coinCurrentX[coinIndex] = kCharacterColumnWidth - 1;
}
else
{
	_coinActive[coinIndex] = FALSE;
}
			}
		}

		// update frame
		_coinFrame[coinIndex]++;
		if(_coinFrame[coinIndex] == kCoinFrameCount)
		{
			_coinFrame[coinIndex] = 0;
		}



		// draw
		if(coinIndex == 0)
		{
			NIRVANAP_halt();
		}

		NIRVANAP_paintC(_coinBlackAttributeValues, _coinCurrentY[coinIndex], _coinPreviousX[coinIndex]);
		_coinPreviousX[coinIndex] = _coinCurrentX[coinIndex];

		if(_coinActive[coinIndex])
		{

			NIRVANAP_printC(_coinFrame[coinIndex], 
					_coinAttributeValues, 
					_coinCurrentY[coinIndex], 
					_coinCurrentX[coinIndex]);
		}
		else
		{
			NIRVANAP_printC(kCoinInactiveDrawFrame, 
					_coinBlackAttributeValues, 
					_coinCurrentY[coinIndex], 
					kCoinInactiveDrawX);
		}

	}	
}

void CoinsUpdatePlayerLowYOptimisedCollisionCheckVersion()
{
	// TODO - making proper coin system when not drinking, this is just to test some character drawing
	//unsigned char coinCurrentX, coinCurrentY; // assigning into these seemed to make things slower?
	
	// TODO IMPORTANT check - a Coin struct may compile far more efficient than indexing into all these seperate arrays!!!!
	// TODO If the above is true, do the same for the Spriute data etc??  Rather than indexiing into seperate arrays in loops!

	for(unsigned char coinIndex = 0; coinIndex < kCoinCount; coinIndex++)
	{
		// move if active, check offscreen (TODO collision detection will also go here)
		if(_coinActive[coinIndex])
		{
			_coinCurrentX[coinIndex] -= kScrollSpeedCurrent;

			if
			(
				_coinCurrentX[coinIndex] > kCharacterColumnWidth 
				|| 
				(	_coinCurrentX[coinIndex] < kPlayerStartX + 3 // TODO make kPlayerCoinCollisionWidth define
					&& _coinCurrentX[coinIndex] >= kPlayerStartX
					&& _coinCurrentY[coinIndex] < _playerY + kScreenTileHeight	
					&& _coinCurrentY[coinIndex] >= _playerY 
				)
			)
			{

if(_coinCurrentX[coinIndex] > kCharacterColumnWidth)
{
	_coinCurrentX[coinIndex] = kCharacterColumnWidth - 1;
}
else
{
	_coinActive[coinIndex] = FALSE;
}
			}
		}

		// update frame
		_coinFrame[coinIndex]++;
		if(_coinFrame[coinIndex] == kCoinFrameCount)
		{
			_coinFrame[coinIndex] = 0;
		}



		// draw
		if(coinIndex == 0)
		{
			NIRVANAP_halt();
		}

		NIRVANAP_paintC(_coinBlackAttributeValues, _coinCurrentY[coinIndex], _coinPreviousX[coinIndex]);
		_coinPreviousX[coinIndex] = _coinCurrentX[coinIndex];

		if(_coinActive[coinIndex])
		{

			NIRVANAP_printC(_coinFrame[coinIndex], 
					_coinAttributeValues, 
					_coinCurrentY[coinIndex], 
					_coinCurrentX[coinIndex]);
		}
		else
		{
			NIRVANAP_printC(kCoinInactiveDrawFrame, 
					_coinBlackAttributeValues, 
					_coinCurrentY[coinIndex], 
					kCoinInactiveDrawX);
		}

	}	
}



