#include "headers.h"

#include "floor.c"
#include "coins.c"
#include "game.c"
#include "enemies.c"
#include "sprites.c"
#include "player.c"


#pragma output CLIB_OPT_PRINTF       = 0x00000400   // enable %c for printf only
#pragma output CLIB_MALLOC_HEAP_SIZE = 0            // do not create a heap
#pragma output REGISTER_SP           = -1           // do not change sp


main()
{
	App();
	
	return 0;
}

void App()
{
	AppInitialise();

	// this is all todo once we need a front end and have app states

	Game();
}

void AppInitialise()
{
	// TODO states - Launch, Frontend, Ingame (Gameover? may be part of Frontend)
}








