#ifndef __FLOOR_H__
#define __FLOOR_H__



#define kCeilingAddress (kMemoryScreenAttributeDataStart)
#define kFloorAddress (kMemoryScreenAttributeDataStart + ((kNirvanaCompiledCharacterHeight + 1) * kCharacterColumnWidth))

#define kFloorAttributeBrightCyanBlue ATTRIBUTE_ENCODE(INK_CYAN, INK_BLUE, TRUE, FALSE)
#define kFloorAttributeBrightBlueCyan ATTRIBUTE_ENCODE(INK_BLUE, INK_CYAN, TRUE, FALSE)
#define kFloorAttributeBrightCyanCyan ATTRIBUTE_ENCODE(INK_CYAN, INK_CYAN, TRUE, FALSE)
#define kFloorAttributeBrightBlueBlue ATTRIBUTE_ENCODE(INK_BLUE, INK_BLUE, TRUE, FALSE)

#define kFloorAttributeDarkCyanBlue ATTRIBUTE_ENCODE(INK_CYAN, INK_BLUE, FALSE, FALSE)
#define kFloorAttributeDarkBlueCyan ATTRIBUTE_ENCODE(INK_BLUE, INK_CYAN, FALSE, FALSE)
#define kFloorAttributeDarkCyanCyan ATTRIBUTE_ENCODE(INK_CYAN, INK_CYAN, FALSE, FALSE)
#define kFloorAttributeDarkBlueBlue ATTRIBUTE_ENCODE(INK_BLUE, INK_BLUE, FALSE, FALSE)

#define kFloorPatternLoopWidth (16)

const unsigned char _floorAttributeValues1[] = 
{
	// 32 for the screen
	kFloorAttributeBrightCyanBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue,
	kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue,
	kFloorAttributeBrightBlueCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan,
	kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan,
	kFloorAttributeBrightCyanBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue,
	kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue,
	kFloorAttributeBrightBlueCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan,
	kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan,
	// additional kFloorPatternLoopWidth for one repeat
	kFloorAttributeBrightCyanBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue,
	kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue, kFloorAttributeBrightBlueBlue,
	kFloorAttributeBrightBlueCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan,
	kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan, kFloorAttributeBrightCyanCyan,
};

const unsigned char _ceilingAttributeValues1[] = 
{
	// 32 for the screen
	kFloorAttributeDarkCyanBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue,
	kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue,
	kFloorAttributeDarkBlueCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan,
	kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan,
	kFloorAttributeDarkCyanBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue,
	kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue,
	kFloorAttributeDarkBlueCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan,
	kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan,
	// additional kFloorPatternLoopWidth for one repeat
	kFloorAttributeDarkCyanBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue,
	kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue, kFloorAttributeDarkBlueBlue,
	kFloorAttributeDarkBlueCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan,
	kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan, kFloorAttributeDarkCyanCyan,
};


void FloorInitialise();
void FloorUpdate();

unsigned char _floorOffset;

#endif
