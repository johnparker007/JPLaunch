#ifndef __ENEMIES_H__
#define __ENEMIES_H__


#define kEnemyCount (kSpriteCount - 1)

unsigned char _enemyX[kEnemyCount];
unsigned char _enemyY[kEnemyCount];
unsigned char _enemyVx[kEnemyCount];
unsigned char _enemyVy[kEnemyCount];

void EnemiesInitialise();
void EnemiesUpdate();


#endif
