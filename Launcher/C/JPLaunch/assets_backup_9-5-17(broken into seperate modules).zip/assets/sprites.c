#include "headers.h"

void SpriteInitialise()
{
	for(unsigned char spriteIndex = 0; spriteIndex < kSpriteCount; spriteIndex++)
	{
		_spriteTileIndex[spriteIndex] = 0;
		_spritePixelRow[spriteIndex] = 0;
		_spriteCharacterColumn[spriteIndex] = 0;
	}
}

void SpriteUpdate()
{
	for(unsigned char spriteIndex = 0; spriteIndex < kSpriteCount; spriteIndex++)
	{
		// TODO will prob need this when all sprites are visible
		// if (sprite == 0 || sprite == 3 || sprite == 6)
		//		NIRVANAP_halt();

		if(spriteIndex == 0 || spriteIndex == 4)
		{
			NIRVANAP_halt();
		}
 
		NIRVANAP_fillT(0, *SPRITELIN(spriteIndex), *SPRITECOL(spriteIndex));
	    NIRVANAP_spriteT(spriteIndex, 
			_spriteTileIndex[spriteIndex], 
			_spritePixelRow[spriteIndex], 
			_spriteCharacterColumn[spriteIndex]);
	}
}