#include "headers.h"

void FloorInitialise()
{
	_floorOffset = 0;
}

void FloorUpdate()
{
	_floorOffset += kScrollSpeedCurrent;
	if(_floorOffset == kFloorPatternLoopWidth)
	{
		_floorOffset = 0;
	}

	memcpy((void *)kCeilingAddress, _ceilingAttributeValues1 + _floorOffset, kCharacterColumnWidth);
	memcpy((void *)kFloorAddress, _floorAttributeValues1 + _floorOffset, kCharacterColumnWidth);
	
	memcpy((void *)(kFloorAddress + 32), _floorAttributeValues1 + _floorOffset, kCharacterColumnWidth);	
	memcpy((void *)(kFloorAddress + 32), _floorAttributeValues1 + _floorOffset, kCharacterColumnWidth);	
	memcpy((void *)(kFloorAddress + 96), _floorAttributeValues1 + _floorOffset, kCharacterColumnWidth);	
	memcpy((void *)(kFloorAddress + 128), _floorAttributeValues1 + _floorOffset, kCharacterColumnWidth);	
}


