#ifndef __PLAYER_H__
#define __PLAYER_H__


#define kPlayerTileIndexGround (6)
#define kPlayerTileIndexAir (7)

#define kPlayerSpriteIndex (kSpriteFinalIndex) // higher are drawn on top, player should always be in front

#define kPlayerMinimumY (kPixelRowStart)
#define kPlayerMaximumY (kPixelRowCount)
#define kPlayerMediumY (kPixelRowStart + (kPixelRowCount / 2))

#define kPlayerStartX (4)
#define kPlayerStartY (kPlayerMaximumY)

#define kPlayerMaximumBoost (kPixelRowHeight * 4) // pixels/frame
#define kPlayerTerminalVelocity (kPixelRowHeight * 3)

unsigned char _playerY;
signed char _playerVy; // TODO this is less efficient than using unsigned: "including the z80, are better suited to unsigned types and use of unsigned char rather than signed char leads to faster and more compact code"

void PlayerInitialise();
void PlayerUpdate();




#endif
