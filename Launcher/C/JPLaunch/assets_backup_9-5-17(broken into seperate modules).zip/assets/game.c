#include "headers.h"

extern unsigned char btiles[];

void Game()
{
	GameInitialise();
	GameUpdate();
}

void GameInitialise()
{
	GameInitialiseScreen();
	GameInitialiseNirvana();
	SpriteInitialise();
	PlayerInitialise();
	EnemiesInitialise();
	CoinsInitialise();
	FloorInitialise();
}

void GameInitialiseScreen()
{
    zx_border(PAPER_BLACK);
	zx_cls(PAPER_BLACK);

	// for the floor/ceiling: TODO this doesn't work in sdcc, need different print character routine? (want fast one for ingame HUD printing anyway)
	printUDGAddress(GET_HIGH_BYTE(kCharacterSetAddress), GET_LOW_BYTE(kCharacterSetAddress));
    printAt(0, 0);
	printf("++++++++++++++++++++++++++++++++"); // ceiling
    printAt(kNirvanaCompiledCharacterHeight + 1, 0);
	printf("********************************"); // floor
	
    printAt(kNirvanaCompiledCharacterHeight + 2, 0);
	printf("********************************"); // floor
    printAt(kNirvanaCompiledCharacterHeight + 3, 0);
	printf("********************************"); // floor
    printAt(kNirvanaCompiledCharacterHeight + 4, 0);
	printf("********************************"); // floor
    printAt(kNirvanaCompiledCharacterHeight + 5, 0);
	printf("********************************"); // floor	
}

void GameInitialiseNirvana()
{
    NIRVANAP_tiles(btiles);
    NIRVANAP_start();
}

void GameUpdate()
{
	for(;;) // (maybe this will end up being 'while(!gameover)' etc, though could jump out for one less test per frame
	{
		SpriteUpdate(); // TODO it may matter if this is at beginning vs end of update
		PlayerUpdate();
		EnemiesUpdate();
		CoinsUpdate();
		FloorUpdate();
	}
}