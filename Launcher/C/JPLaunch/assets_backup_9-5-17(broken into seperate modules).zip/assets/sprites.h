#ifndef __SPRITES_H__
#define __SPRITES_H__


#define kSpriteCount (8)
#define kSpriteFinalIndex (kSpriteCount - 1)

unsigned char _spriteTileIndex[kSpriteCount];
unsigned char _spritePixelRow[kSpriteCount];
unsigned char _spriteCharacterColumn[kSpriteCount];

void SpriteInitialise();
void SpriteUpdate();


#endif
