#ifndef __HEADERS_H__
#define __HEADERS_H__

#include <string.h> // JP: for memcpy() 
#include <stdio.h>
#include <stdlib.h>
#include <input.h>

#include <arch/zx.h>
#include <arch/zx/nirvana+.h>

#include "macros.h"

#include "app.h"
#include "game.h"

#include "floor.h"
#include "coins.h"
#include "sprites.h"
#include "player.h"
#include "enemies.h"


typedef unsigned char uchar;
typedef unsigned int uint;


#endif
