#ifndef __COINS_H__
#define __COINS_H__


#define kCoinCount (8)
#define kCoinFrameCount (6)

#define kCoinInactiveDrawX (0)
#define kCoinInactiveDrawFrame (10)

void CoinsInitialise();
void CoinsUpdate();
void CoinsUpdatePlayerLowYOptimisedCollisionCheckVersion();
void CoinsUpdatePlayerHighYOptimisedCollisionCheckVersion();

unsigned char _coinPreviousX[kCoinCount];
unsigned char _coinCurrentX[kCoinCount];
unsigned char _coinCurrentY[kCoinCount];
unsigned char _coinFrame[kCoinCount];
unsigned char _coinActive[kCoinCount]; // TODO bools are faster under SDCC, not supported in SCCZ80

// TODO relevant define for the 4 to represent the 4 * 2 pixel rows to be coloured
unsigned char _coinAttributeValues[4];
unsigned char _coinBlackAttributeValues[4]; // this may want to be more general purpose, as could be used on things other than coins

struct Coin
{
	int test;
};

#endif
