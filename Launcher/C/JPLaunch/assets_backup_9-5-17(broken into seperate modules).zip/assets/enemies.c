#include "headers.h"

void EnemiesInitialise()
{
	for(unsigned char enemyIndex = 0; enemyIndex < kEnemyCount; enemyIndex++)
	{
		_enemyX[enemyIndex] = 0;
		_enemyY[enemyIndex] = 0;
		_enemyVx[enemyIndex] = 0;
		_enemyVy[enemyIndex] = 0;
	}

	EnemiesInitialiseTestPositionsAndVelocities(); // XXX temp for testing
}

void EnemiesInitialiseTestPositionsAndVelocities()
{
	for(unsigned char enemyIndex = 0; enemyIndex < kEnemyCount; enemyIndex++)
	{
		_enemyX[enemyIndex] = 12 + (enemyIndex * 2);
		_enemyY[enemyIndex] = 40 + (enemyIndex * 8);
		_enemyVx[enemyIndex] = 0;
		_enemyVy[enemyIndex] = 2;
	}
}

void EnemiesUpdate()
{
	for(unsigned char enemyIndex = 0; enemyIndex < kEnemyCount; enemyIndex++)
	{
		// Apply velocity
		_enemyX[enemyIndex] += _enemyVx[enemyIndex];
		_enemyY[enemyIndex] += _enemyVy[enemyIndex];

		// XXX temp for testing
		if(_enemyY[enemyIndex] > kPlayerMaximumY)
		{
			//_spriteTileIndex[kPlayerSpriteIndex] = kPlayerTileIndexGround;
			_enemyY[enemyIndex] = kPlayerMaximumY;
			_enemyVy[enemyIndex] = -_enemyVy[enemyIndex];
		}
		else
		{
			//_spriteTileIndex[kPlayerSpriteIndex] = kPlayerTileIndexAir;
			if(_enemyY[enemyIndex] < kPlayerMinimumY)
			{
				_enemyY[enemyIndex] = kPlayerMinimumY;
				_enemyVy[enemyIndex] = -_enemyVy[enemyIndex];
			}
		}

		// Sprite position
		_spritePixelRow[enemyIndex] = _enemyY[enemyIndex];
		_spriteCharacterColumn[enemyIndex] = _enemyX[enemyIndex];
	}
}

