#include "headers.h"

void PlayerInitialise()
{
	_playerY = kPlayerStartY;
	_playerVy = 0;

	_spriteCharacterColumn[kPlayerSpriteIndex] = kPlayerStartX;
}

void PlayerUpdate()
{
	// Thrust
	if(in_test_key())
	{
		//_playerY -= 4;
		_playerVy -= kPixelRowHeight * 2;
		if(_playerVy < -kPlayerMaximumBoost)
		{
			_playerVy = -kPlayerMaximumBoost;
		}
	}

	// Gravity
	_playerVy += kPixelRowHeight;
	if(_playerVy > kPlayerTerminalVelocity)
	{
		_playerVy = kPlayerTerminalVelocity;
	}

	// Apply velocity
	_playerY += _playerVy;

	// Sprite frame and Y clamp
	if(_playerY > kPlayerMaximumY)
	{
		_spriteTileIndex[kPlayerSpriteIndex] = kPlayerTileIndexGround;
		_playerY = kPlayerMaximumY;
		_playerVy = 0;
	}
	else
	{
		_spriteTileIndex[kPlayerSpriteIndex] = kPlayerTileIndexAir;
		if(_playerY < kPlayerMinimumY)
		{
			_playerY = kPlayerMinimumY;
			_playerVy = 0;
		}
	}

	// Sprite position
	_spritePixelRow[kPlayerSpriteIndex] = _playerY;
}
